"""Promote simple blocks (Ola1) from sweep proxies and SM matches."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import numpy as np
from ola1.sm_matching import load_universe


DEFAULT_SELECTION = {
    "band_count_max": 7,
    "lock_quality_Q_min": 0.35,
    "structure_tier_min": "level1",
    "log_rejections": True,
    "grades": {
        "use_d_total_for_grades_only": True,
        "grade_A_d_total_max": 0.5,
        "grade_B_d_total_max": 1.5,
    },
}


def read_proxies(path: Path) -> List[Dict]:
    rows = []
    with path.open() as f:
        reader = csv.DictReader(f)
        for row in reader:
            parsed = {}
            for k, v in row.items():
                try:
                    parsed[k] = float(v)
                except Exception:
                    parsed[k] = v
            rows.append(parsed)
    return rows


def _hash_text(text: str) -> str:
    try:
        import hashlib

        return hashlib.sha256(text.encode("utf-8")).hexdigest()
    except Exception:
        return ""


def _norm_run_id(val) -> str:
    try:
        f = float(val)
        return str(int(f))
    except Exception:
        return str(val)


def read_matches(path: Path) -> List[Dict]:
    rows = []
    with path.open() as f:
        reader = csv.DictReader(f)
        for row in reader:
            parsed = {}
            for k, v in row.items():
                try:
                    parsed[k] = float(v)
                except Exception:
                    parsed[k] = v
            rows.append(parsed)
    return rows


def read_dof_catalog(path: Path) -> Dict[str, Dict[str, object]]:
    if not path.exists():
        return {}
    rows: Dict[str, Dict[str, object]] = {}
    with path.open() as f:
        reader = csv.DictReader(f)
        for row in reader:
            rid = _norm_run_id(row.get("run_id"))
            dof_grade = str(row.get("dof_grade") or row.get("dna_grade") or "").upper()
            if not dof_grade:
                try:
                    d_total = float(row.get("d_total"))
                except Exception:
                    d_total = None
                if d_total is None or not np.isfinite(d_total):
                    dof_grade = ""
                elif d_total < 0.5:
                    dof_grade = "A"
                elif d_total < 1.5:
                    dof_grade = "B"
                else:
                    dof_grade = "C"
            rows[rid] = {
                "dof_grade": dof_grade if dof_grade else None,
                "sm_d_total": row.get("sm_d_total"),
            }
    return rows


def _tier_rank(tier: str) -> int:
    order = {"none": 0, "level1": 1, "level2": 2, "level3": 3}
    return order.get(str(tier), 0)


def _normalize_s_state(state: Optional[str]) -> str:
    s = (str(state or "")).lower()
    if s.startswith("structural"):
        return "structural"
    return s


def _family_level_count(proxy_row: Dict, family: Optional[str]) -> int:
    if not family:
        return 0
    target_key = f"{family}_n_levels_sim".lower()
    for k, v in proxy_row.items():
        if str(k).lower() == target_key:
            try:
                return int(float(v))
            except Exception:
                return 0
    return 0


def _allowed_s2(state: Optional[str], allowed: Set[str]) -> bool:
    return _normalize_s_state(state) in allowed


def _threshold_for(particle: Dict) -> Tuple[int, float, int, Set[str]]:
    """Return (min_tier_rank, max_d_total, min_levels, allowed_s2_states)."""
    ptype = particle.get("type")
    name = particle.get("name")
    if ptype == "meson":
        d_yes = 0.3
        min_levels = 1 if name == "pion" else 2
        return 1, d_yes, min_levels, {"none", "latent", "structural"}
    if ptype == "effective_quark":
        return 1, 0.5, 1, {"none", "latent", "structural"}
    if ptype == "baryon":
        # handled via complex cores
        return 3, float("inf"), 3, {"latent", "structural"}
    # default conservative
    return 2, 0.5, 2, {"none", "latent", "structural"}


def main():
    parser = argparse.ArgumentParser(description="Promote simple blocks from Ola1 sweeps.")
    parser.add_argument("--proxies-csv", type=Path, required=True)
    parser.add_argument("--zoo-matches-csv", type=Path, required=True)
    parser.add_argument("--sm-universe", type=Path, default=None)
    parser.add_argument("--output", type=Path, default=Path("data/processed/ola1/simple_blocks.json"))
    parser.add_argument(
        "--digest",
        type=Path,
        default=Path("data/processed/digest/ola1"),
        help="Directory to store promoted block summary.",
    )
    parser.add_argument(
        "--config-dir",
        type=Path,
        default=Path("data/config/ola1_paper"),
        help="Base directory for ola1 configs (defaults to data/config/ola1_paper).",
    )
    parser.add_argument(
        "--selection-config",
        type=Path,
        default=None,
        help="Selection thresholds for Ola1->Ola2 physical filters.",
    )
    parser.add_argument(
        "--selection-log",
        type=Path,
        default=Path("data/processed/ola1/ola1_blocks_selection.csv"),
        help="Optional CSV log of accepted/rejected runs.",
    )
    parser.add_argument(
        "--dof-dna-catalog",
        type=Path,
        default=None,
        help="Optional DOF DNA catalog; only Grade A runs are promoted.",
    )
    parser.add_argument("--d-total-max", type=float, default=None, help="Deprecated: ignored.")
    parser.add_argument("--max-blocks-per-particle", type=int, default=5000)
    args = parser.parse_args()

    sm_universe = args.sm_universe or (args.config_dir / "sm_universe.json")
    proxies = read_proxies(args.proxies_csv)
    matches = read_matches(args.zoo_matches_csv)
    # selection config
    sel_cfg = DEFAULT_SELECTION
    sel_cfg_path_str = ""
    sel_cfg_hash = ""
    selection_config = args.selection_config or (args.config_dir / "wave1_selection.json")
    if selection_config and selection_config.exists():
        try:
            import json as _json

            sel_cfg_path_str = str(selection_config)
            sel_text = selection_config.read_text()
            sel_cfg_hash = _hash_text(sel_text)
            loaded = _json.loads(sel_text) or {}
            sel_cfg = {**sel_cfg, **loaded}
            if "grades" in loaded:
                sel_cfg["grades"] = {**DEFAULT_SELECTION["grades"], **loaded.get("grades", {})}
            print(f"[promote_simple_blocks] Loaded selection config from {sel_cfg_path_str}")
        except Exception:
            print("[promote_simple_blocks] Failed to load selection config; using defaults.")
            sel_cfg = DEFAULT_SELECTION
    else:
        print("[promote_simple_blocks] Using default selection config.")
    # optional runs JSON to retrieve theta_internal
    runs_json = None
    if args.proxies_csv.name.endswith("_all_runs_proxies.csv"):
        case = args.proxies_csv.stem.replace("_all_runs_proxies", "")
        candidate = Path("data/processed/ola1") / case / "global" / "study05_sweep_results.json"
        if candidate.exists():
            runs_json = candidate
    if runs_json is None:
        candidate = Path(args.proxies_csv).parent.parent / "global" / "study05_sweep_results.json"
        if candidate.exists():
            runs_json = candidate
    run_theta: Dict[str, Dict] = {}
    if runs_json and runs_json.exists():
        try:
            data = json.loads(runs_json.read_text())
            for r in data.get("runs", []):
                run_theta[str(r.get("run_id"))] = r.get("theta_internal")
        except Exception:
            pass
    universe = load_universe(sm_universe)
    catalog = universe.get("particles", universe)
    cat_by_name = {p["name"]: p for p in catalog}
    proxy_by_run = {_norm_run_id(r.get("run_id")): r for r in proxies}
    dna_path = args.dof_dna_catalog or (Path(args.proxies_csv).parent / "dof_dna_catalog.csv")
    dof_by_run = read_dof_catalog(dna_path)

    def _to_float(val):
        try:
            return float(val)
        except Exception:
            return None

    def _as_bool(val) -> bool:
        if isinstance(val, bool):
            return val
        if isinstance(val, (int, float)):
            return val != 0
        if isinstance(val, str):
            v = val.strip().lower()
            if v in {"true", "yes", "y", "1"}:
                return True
            if v in {"false", "no", "n", "0", ""}:
                return False
        return bool(val)

    # choose best match per run (lowest finite d_total)
    best_by_run: Dict[str, Dict] = {}
    for m in matches:
        rid = _norm_run_id(m.get("run_id"))
        d_total = m.get("d_total", np.inf)
        if not np.isfinite(d_total):
            continue
        prev = best_by_run.get(rid)
        if prev is None or d_total < prev.get("d_total", np.inf):
            best_by_run[rid] = m
    # ensure all runs from proxies are considered (even without match)
    all_run_ids = {_norm_run_id(r.get("run_id")) for r in proxies}

    blocks: List[Dict] = []
    blocks_per_particle: Dict[str, int] = {}
    rejected_rows: List[Dict] = []
    selection_log_rows: List[Dict[str, object]] = []
    baryon_candidates: List[Dict[str, object]] = []

    for run_id in all_run_ids:
        match = best_by_run.get(run_id)
        target = match.get("target_name") if match else None
        particle = cat_by_name.get(target or "") if match else None
        proxy_row = proxy_by_run.get(run_id)
        band_count_struct = proxy_row.get("band_count_structural") if proxy_row else None
        band_count = band_count_struct if band_count_struct is not None else proxy_row.get("band_count") if proxy_row else None
        band_count = _to_float(band_count)
        structural_cap_hit = False
        peak_cap_hit = False
        if proxy_row:
            structural_cap_hit = _as_bool(proxy_row.get("band_structural_cap_hit"))
            peak_cap_hit = _as_bool(proxy_row.get("peak_cap_hit"))
        raw_lock_q = proxy_row.get("lock_quality_Q") if proxy_row else None
        try:
            lock_q = float(raw_lock_q)
        except Exception:
            lock_q = None
        structure_tier = proxy_row.get("structure_tier", "none") if proxy_row else "none"
        reasons: List[str] = []
        dof_record = dof_by_run.get(run_id, {})
        dof_grade = str(dof_record.get("dof_grade") or "").upper()
        if dof_by_run:
            if dof_grade and dof_grade != "A":
                reasons.append("dof_grade_not_a")
            elif not dof_grade:
                reasons.append("dof_missing")

        # Physical filters (no d_total here)
        try:
            band_count_max = float(sel_cfg.get("band_count_max", 1e9))
        except Exception:
            band_count_max = 1e9
        if band_count is not None and band_count > band_count_max:
            reasons.append(f"too_many_struct_bands>{band_count_max}")
        if structural_cap_hit or peak_cap_hit:
            reasons.append("structural_band_cap_hit")
        if lock_q is not None and lock_q < sel_cfg.get("lock_quality_Q_min", 0.0):
            reasons.append(f"low_Q_lock<{sel_cfg.get('lock_quality_Q_min')}")
        order = {"none": 0, "level1": 1, "level2": 2, "level3": 3}
        min_tier = sel_cfg.get("structure_tier_min", "level1")
        if order.get(str(structure_tier), 0) < order.get(str(min_tier), 0):
            reasons.append(f"tier_below_{min_tier}")

        if match is None or target is None:
            reasons.append("missing_match")
        else:
            try:
                n_levels_sim = float(match.get("n_levels_sim", 0))
            except Exception:
                n_levels_sim = 0.0
            if n_levels_sim <= 0:
                reasons.append("missing_levels")
        if particle is None:
            reasons.append("unknown_particle")
        if proxy_row is None:
            reasons.append("missing_proxy")
        policy_rejected = 0
        if match:
            try:
                policy_rejected = int(float(match.get("policy_rejected", 0)))
            except Exception:
                policy_rejected = 0
            if policy_rejected:
                reasons.append("policy_rejected")

        if particle and particle.get("type") == "baryon":
            baryon_candidates.append(
                {
                    "run_id": run_id,
                    "best_target": target,
                    "best_d_total": (match or {}).get("d_total"),
                    "structure_tier": structure_tier,
                    "s2_state": proxy_row.get("s2_state") if proxy_row else "",
                    "band_count_structural": band_count,
                    "band_count": band_count,
                    "lock_quality_Q": lock_q,
                    "lock_quality_S1": proxy_row.get("lock_quality_S1") if proxy_row else None,
                    "lock_quality_S2": proxy_row.get("lock_quality_S2") if proxy_row else None,
                    "reasons": ";".join(reasons),
                    "selection_config_path": sel_cfg_path_str,
                    "selection_config_hash": sel_cfg_hash,
                }
            )

        # log selection decision
        if sel_cfg.get("log_rejections", False):
            selection_log_rows.append(
                {
                    "run_id": run_id,
                    "accepted": 0 if reasons else 1,
                    "reasons": ";".join(reasons) if reasons else "",
                    "band_count": band_count,
                    "lock_quality_Q": lock_q,
                    "structure_tier": structure_tier,
                    "d_total_best": (match or {}).get("d_total"),
                }
            )

        name_allowed = True
        if match is None or target is None or particle is None:
            name_allowed = False
        if policy_rejected:
            name_allowed = False
        if match is not None:
            try:
                n_levels_sim = float(match.get("n_levels_sim", 0))
            except Exception:
                n_levels_sim = 0.0
            if n_levels_sim <= 0:
                name_allowed = False

        target_name = target if name_allowed else "unknown"
        particle_name = target_name
        particle_obj = particle if name_allowed else None
        cnt = blocks_per_particle.get(target_name, 0)
        if cnt >= args.max_blocks_per_particle:
            name_allowed = False
            target_name = "unknown"
            particle_name = "unknown"
            particle_obj = None
            cnt = blocks_per_particle.get(target_name, 0)
        blocks_per_particle[target_name] = cnt + 1

        block_id = f"{target_name}_block_{cnt+1:04d}"
        d_total = (match or {}).get("d_total", np.inf)
        grade_cfg = sel_cfg.get("grades", {})
        grade_A = grade_cfg.get("grade_A_d_total_max", 0.5)
        grade_B = grade_cfg.get("grade_B_d_total_max", 1.5)
        if np.isfinite(d_total) and d_total <= grade_A:
            grade = "A"
        elif np.isfinite(d_total) and d_total <= grade_B:
            grade = "B"
        else:
            grade = "C"
        s2_state_norm = _normalize_s_state(proxy_row.get("s2_state"))
        # derive a band-based s2 state for clarity
        try:
            s2_frac = float(proxy_row.get("s2_band_fraction", 0.0))
        except Exception:
            s2_frac = 0.0
        if s2_frac < 0.02:
            s2_state_band = "none"
        elif s2_frac < 0.12:
            s2_state_band = "latent"
        else:
            s2_state_band = "structural"
        # sanitise match distances (avoid NaN in JSON)
        def _nan_to_none(val):
            try:
                v = float(val)
                return v if np.isfinite(v) else None
            except Exception:
                return None
        d_spacing_clean = _nan_to_none((match or {}).get("d_spacing"))
        d_mass_clean = _nan_to_none((match or {}).get("d_mass"))
        d_total_clean = _nan_to_none((match or {}).get("d_total"))
        dna_grade = dof_grade if dof_grade else "unknown"
        block = {
            "block_id": block_id,
            "origin_run_id": proxy_row.get("run_id"),
            "particle_name": particle_name,
            "family": (particle_obj.get("family") if particle_obj else "unknown"),
            "type": (particle_obj.get("type") if particle_obj else "unknown"),
            "grade": grade,
            "dna_grade": dna_grade,
            "structure_tier": structure_tier,
            "lock_quality": {
                "Q": proxy_row.get("lock_quality_Q"),
                "S1": proxy_row.get("lock_quality_S1"),
                "S2": proxy_row.get("lock_quality_S2"),
            },
            "s2_state": s2_state_norm,
            "s2_state_band": s2_state_band,
            "s2_state_lock": proxy_row.get("s2_state_lock"),
            "band_count": band_count,
            "s2_band_fraction": proxy_row.get("s2_band_fraction"),
            "band_dom_counts_total": proxy_row.get("band_dom_counts_total"),
            "band_dom_counts_structural": proxy_row.get("band_dom_counts_structural"),
            "match_score": {
                "d_total": d_total_clean,
                "d_spacing": d_spacing_clean,
                "d_mass": d_mass_clean,
                "n_levels_sim": (match or {}).get("n_levels_sim"),
                "has_enough_levels_full": bool((match or {}).get("enough_levels_full")),
                "has_enough_levels_partial": bool((match or {}).get("enough_levels_partial")),
            },
            "theta_internal": {
                "R_S1_Q": proxy_row.get("R_S1_Q"),
                "R_S2_S1": proxy_row.get("R_S2_S1"),
                "R_S3_S2": proxy_row.get("R_S3_S2"),
                "g_couplings": proxy_row.get("g_couplings"),
                "memory_taus": proxy_row.get("memory_taus"),
                "memory_amps": proxy_row.get("memory_amps"),
                "n_memory_terms": proxy_row.get("n_memory_terms"),
                "memory_terms_by_layer": proxy_row.get("memory_terms_by_layer"),
            },
            "layer_energy_fraction": proxy_row.get("layer_energy_fraction"),
            "participation_entropy": proxy_row.get("participation_entropy"),
            "min_layer_fraction": proxy_row.get("min_layer_fraction"),
            "internal_energy": _to_float(proxy_row.get("E_internal")),
            # lock/mass proxies (Ola1 internal units)
            "omega_ref": _to_float(proxy_row.get("omega_ref")),
            "V_layers": _to_float(proxy_row.get("V_layers")),
            "V_lock": _to_float(proxy_row.get("V_lock")),
            "D_stat": _to_float(proxy_row.get("D_stat")),
            "D_dyn": _to_float(proxy_row.get("D_dyn")),
            "rho_lock": _to_float(proxy_row.get("rho_lock")),
            "M_spec": _to_float(proxy_row.get("M_spec")),
            "M1": _to_float(proxy_row.get("M1")),
            "M2": _to_float(proxy_row.get("M2")),
            "M3": _to_float(proxy_row.get("M3")),
            "omega_ref_interp": _to_float(proxy_row.get("omega_ref_interp")),
            "f_ref": _to_float(proxy_row.get("f_ref")),
            "delta_omega": _to_float(proxy_row.get("delta_omega")),
            "delta_f": _to_float(proxy_row.get("delta_f")),
            "fft_peak_index": _to_float(proxy_row.get("fft_peak_index")),
            "fft_peak_delta": _to_float(proxy_row.get("fft_peak_delta")),
            "fft_peak_mag_km1": _to_float(proxy_row.get("fft_peak_mag_km1")),
            "fft_peak_mag_k": _to_float(proxy_row.get("fft_peak_mag_k")),
            "fft_peak_mag_kp1": _to_float(proxy_row.get("fft_peak_mag_kp1")),
            "mass_sim_gev": _to_float(proxy_row.get("mass_sim_gev")),
            "mass_sim_used_gev": _to_float(proxy_row.get("mass_sim_used_gev")),
        }
        theta_full = run_theta.get(str(proxy_row.get("run_id")))
        if theta_full:
            block["theta_internal"] = theta_full
        blocks.append(block)

    out_path = args.output
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(blocks, indent=2))

    # Console summary per particle
    if blocks:
        try:
            print("Block summary (particle_name):")
            by_particle: Dict[str, List[Dict]] = defaultdict(list)
            for b in blocks:
                by_particle[b.get("particle_name")].append(b)
            for name, arr in by_particle.items():
                d_vals = []
                for b in arr:
                    ms = b.get("match_score") or {}
                    dv = ms.get("d_total")
                    try:
                        d_vals.append(float(dv))
                    except Exception:
                        pass
                tiers = Counter(str(b.get("structure_tier")) for b in arr)
                s2_states = Counter(str(b.get("s2_state")) for b in arr)
                if d_vals:
                    stats = (np.min(d_vals), np.median(d_vals), np.max(d_vals))
                    stats_str = f"{stats[0]:.3f}/{stats[1]:.3f}/{stats[2]:.3f}"
                else:
                    stats_str = "nan/nan/nan"
                print(
                    f"- {name}: count={len(arr)} d_total[min/med/max]={stats_str} tiers={dict(tiers)} s2={dict(s2_states)}"
                )
        except Exception:
            pass

    if sel_cfg.get("log_rejections", False) and selection_log_rows and args.selection_log:
        args.selection_log.parent.mkdir(parents=True, exist_ok=True)
        with args.selection_log.open("w", newline="") as f:
            fieldnames = [
                "run_id",
                "accepted",
                "reasons",
                "band_count",
                "lock_quality_Q",
                "structure_tier",
                "d_total_best",
                "selection_config_path",
                "selection_config_hash",
            ]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in selection_log_rows:
                row["selection_config_path"] = sel_cfg_path_str
                row["selection_config_hash"] = sel_cfg_hash
                writer.writerow(row)

    # Save rejected candidates for visibility
    if rejected_rows:
        rej_path = out_path.parent / "simple_blocks_rejected.csv"
        with rej_path.open("w", newline="") as f:
            fieldnames = [
                "run_id",
                "best_target",
                "type",
                "best_d_total",
                "structure_tier",
                "s2_state",
                "enough_levels_full",
                "enough_levels_partial",
                "reason",
                "selection_config_path",
                "selection_config_hash",
            ]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rejected_rows:
                row["selection_config_path"] = sel_cfg_path_str
                row["selection_config_hash"] = sel_cfg_hash
                writer.writerow(row)

    # Save baryon candidates (excluded from simple blocks but kept as evidence)
    if baryon_candidates:
        baryon_dir = out_path.parent / "blocks"
        baryon_dir.mkdir(parents=True, exist_ok=True)
        baryon_path = baryon_dir / "baryon_candidates.csv"
        with baryon_path.open("w", newline="") as f:
            fieldnames = [
                "run_id",
                "best_target",
                "best_d_total",
                "structure_tier",
                "s2_state",
                "band_count_structural",
                "band_count",
                "lock_quality_Q",
                "lock_quality_S1",
                "lock_quality_S2",
                "reasons",
                "selection_config_path",
                "selection_config_hash",
            ]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in baryon_candidates:
                writer.writerow(row)

    # Optional digest copy for a concise promoted-blocks snapshot
    if args.digest:
        args.digest.mkdir(parents=True, exist_ok=True)
        (args.digest / out_path.name).write_text(out_path.read_text())


if __name__ == "__main__":
    main()
